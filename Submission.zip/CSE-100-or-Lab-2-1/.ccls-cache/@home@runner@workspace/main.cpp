#include <iostream>
using namespace std;

int main()
{
    // Complete the code the below
    // where indicated '/*Code Here*/'

    /*Code Here*/ age = /*Code Here*/;
    /*Code Here*/ myGrade = /*Code Here*/;
    /*Code Here*/ gpa = /*Code Here*/;
    return 0;
}