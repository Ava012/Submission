#include <iostream>
using namespace std;

int main() {
  // Complete the code the below
  // where indicated '/*Code Here*/'
  // DO NOT CHANGE VARIABLE NAMES

  int age = 9;
  char myGrade = 'A'; // The variable will only have
                      // single letter grades no A+ or A-
  float gpa = 3.5;

  // Do not change the below code
  cout << "My age is:" << age << endl;
  cout << "My grade is:" << myGrade << endl;
  cout << "My GPA is:" << gpa;
  return 0;
}